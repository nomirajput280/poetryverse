# PoetryVerse

PoetryVerse — The World of Poetry.

## Current foundation
- Premium responsive homepage
- Poetry library discovery UI
- Search UI
- Categories
- AI Writer entry point and 300-credit presentation
- Weekly rewards presentation
- Install App prompt UI
- Website/PWA-ready structure
- Poetry card interaction placeholders
- Footer branding: Powered by AI Markaz™

## Next production integrations
Connect Supabase authentication/database, RLS, storage, real search, submissions/moderation, credits ledger, weekly rewards, AI provider gateway, payments, social sharing, PWA service worker/offline sync, and Android packaging.

## Backend architecture update — Deno

PoetryVerse is being shifted away from Supabase for the MVP backend. The new backend lives in `deno/` and uses Deno Deploy + Deno KV for authentication sessions, profiles, poetry submissions, moderation, and approved-poetry discovery. The Next.js frontend talks to the Deno API through `NEXT_PUBLIC_API_URL`.

Supabase is no longer a required dependency of the frontend.
